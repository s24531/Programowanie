package lab07.zad3.paymentMethods;

public abstract class Wallet extends PaymentMethod{
    public Wallet(double funds) {
        super(funds);
    }
}
