package lab07.zad1;

public abstract class Shape {

public abstract double getArea();
public abstract double getPerimeter();


}
