package lab07.zad2;

public abstract class Game {

    protected GameType type;
    protected String name;
}
