package lab07.zad2;

public class PlaystationGame extends Game{
    
    public PlaystationGame(String name) {
        this.name = name;
        type = GameType.PLAYSTATION;
    }
}
