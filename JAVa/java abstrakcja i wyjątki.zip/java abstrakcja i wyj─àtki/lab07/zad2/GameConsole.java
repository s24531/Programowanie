package lab07.zad2;

public abstract class GameConsole {

    public abstract void playGame(Game game);
}
