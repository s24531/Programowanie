package lab07.zad2;

public enum GameType {
    XBOX,PLAYSTATION
}
