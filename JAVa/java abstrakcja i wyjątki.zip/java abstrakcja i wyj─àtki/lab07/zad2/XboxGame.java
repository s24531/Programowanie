package lab07.zad2;

public class XboxGame extends Game{

    public XboxGame(String name) {

        this.name = name;
        type = GameType.XBOX;
    }
}
